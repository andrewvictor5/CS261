/*
 * In this file, you will write the structures and functions needed to
 * implement a priority queue.  Feel free to implement any helper functions
 * you need in this file to implement a priority queue.  Make sure to add your
 * name and @oregonstate.edu email address below:
 *
 * Name: Andrew Victor
 * Email: victoran@oregonstate.edu
 */

#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include "pq.h"
#include "dynarray.h"

int find_min_child(struct pq* pq, int index);

/*
 * This is the structure that represents a priority queue.  You must define
 * this struct to contain the data needed to implement a priority queue.
 */

struct pq{
	
	struct dynarray *heap;	

};

//Helper struct for implementation of functions
 
struct heapdata{
	
	void *value; //Holds the value of each element in the pq
	int priority; //Holds the priority of each element in pq

};

/*
 * This function should allocate and initialize an empty priority queue and
 * return a pointer to it.
 */

struct pq* pq_create() {

struct pq* priorityq = malloc(sizeof(struct pq)); //Allocate memory for the struct
	priorityq->heap = dynarray_create(); //Allocate memory for the array to be held in the struct

	return priorityq;
}


/*
 * This function should free the memory allocated to a given priority queue.
 * Note that this function SHOULD NOT free the individual elements stored in
 * the priority queue.  That is the responsibility of the caller.
 *
 * Params:
 *   pq - the priority queue to be destroyed.  May not be NULL.
 */

void pq_free(struct pq* pq) {
	
	assert(pq);
	dynarray_free(pq->heap);
	free(pq);

}


/*
 * This function should return 1 if the specified priority queue is empty and
 * 0 otherwise.
 *
 * Params:
 *   pq - the priority queue whose emptiness is to be checked.  May not be
 *     NULL.
 *
 * Return:
 *   Should return 1 if pq is empty and 0 otherwise.
 */

int pq_isempty(struct pq* pq) {
	
	if(dynarray_size(pq->heap) != 0){
		return 0; //Means that the array isn't empty (false)
	}
	else{
		return 1; //Means that the array is empty (true)
	}
}

/*
 * This function should insert a given element into a priority queue with a
 * specified priority value.  Note that in this implementation, LOWER priority
 * values are assigned to elements with HIGHER priority.  In other words, the
 * element in the priority queue with the LOWEST priority value should be the
 * FIRST one returned.
 *
 * Params:
 *   pq - the priority queue into which to insert an element.  May not be
 *     NULL.
 *   value - the value to be inserted into pq.
 *   priority - the priority value to be assigned to the newly-inserted
 *     element.  Note that in this implementation, LOWER priority values
 *     should correspond to elements with HIGHER priority.  In other words,
 *     the element in the priority queue with the LOWEST priority value should
 *     be the FIRST one returned.
 */

void pq_insert(struct pq* pq, void* value, int priority) {

	struct heapdata* data = malloc(sizeof(struct heapdata)); //Need somewhere to store the value and the priority of a given element in the pq
	data->value = value; 
	data->priority = priority;
	
	int end = dynarray_size(pq->heap); //Finds the end/last element in the array
	dynarray_insert(pq->heap, end, data); //Insert the given data into the end of the array because this is the first empty element in a heap
	
	while(end > 0){ //If the array is 0 or less it is already ordered
		int parentindex = ((end - 1) / 2); //Find the index of the parent relative to the child in the array
		struct heapdata* parentdata = dynarray_get(pq->heap, parentindex); //Set the parent's data to the found index
		if(parentdata->priority > data->priority){ //Check to see if we need to swap because in a pq, the priority values must be lower in the front of the array
			dynarray_set(pq->heap, parentindex, data); //Swaps the child data to the parent index
			dynarray_set(pq->heap, end, parentdata); //Swaps the parent data to the child's index
			end = parentindex; //Reset the end and see if the condition for the loop still holds true
		}
		else{
			end = -100; //Breaks out of loop 
		}
	}
}


/*
 * This function should return the value of the first item in a priority
 * queue, i.e. the item with LOWEST priority value.
 *
 * Params:
 *   pq - the priority queue from which to fetch a value.  May not be NULL or
 *     empty.
 *
 * Return:
 *   Should return the value of the first item in pq, i.e. the item with
 *   LOWEST priority value.
 */

void* pq_first(struct pq* pq) {

	struct heapdata* data = dynarray_get(pq->heap, 0); //Get data for first element in the heap array
	return data->value; 
}


/*
 * This function should return the priority value of the first item in a
 * priority queue, i.e. the item with LOWEST priority value.
 *
 * Params:
 *   pq - the priority queue from which to fetch a priority value.  May not be
 *     NULL or empty.
 *
 * Return:
 *   Should return the priority value of the first item in pq, i.e. the item
 *   with LOWEST priority value.
 */

int pq_first_priority(struct pq* pq) {

	struct heapdata* data = dynarray_get(pq->heap, 0); //Get data for first element in the heap array
	return data->priority;

}

//Helper function to find the min child of a node 
//To be used in the pq_remove_first function

int find_min_child(struct pq* pq, int i){

	int left = (2 * i) + 1; //Left child equation
	int right = (2 * i) + 2; //Right child equation 
	int size = dynarray_size(pq->heap);

	if(left >= size || right >= size){
		return -100; //Makes sure that the children are within the bounds of the size of the heap array
	}
	
	struct heapdata* leftchild = dynarray_get(pq->heap, left); //Create a struct to store the data for the left child
	struct heapdata* rightchild = dynarray_get(pq->heap, right); //Create a struct to store the data for the right child
	if(leftchild->priority > rightchild->priority){ //Checks to see which child has a lower priority value to be used in the next function
		return right; 
	}
	else{
		return left;
	}
}

/*
 * This function should return the value of the first item in a priority
 * queue, i.e. the item with LOWEST priority value, and then remove that item
 * from the queue.
 *
 * Params:
 *   pq - the priority queue from which to remove a value.  May not be NULL or
 *     empty.
 *
 * Return:
 *   Should return the value of the first item in pq, i.e. the item with
 *   LOWEST priority value.
 */
void* pq_remove_first(struct pq* pq) {
	
	void* value = pq_first(pq); //Get value of the first element in the pq
	struct heapdata* data = dynarray_get(pq->heap, 0); //Create a struct to store data for the first element in the pq
	free(data); //Deletes the memory that was allocated
	struct heapdata* data2 = dynarray_get(pq->heap, -1); //Create a struct to get the data for the last element in the pq
	dynarray_set(pq->heap, 0, data2); //Set the data from the last element in the array to the first place in the array
	dynarray_remove(pq->heap, -1); //Remove the last element in the array to make sure it doesn't go out of bounds
	
	int count = 0;
	while(pq != NULL){
		int minimum = find_min_child(pq, count); //Helper function from earlier
		if(minimum < 0){
			return value; //If this returns true it means the array is already in order
		}
		else{
			struct heapdata* data3 = dynarray_get(pq->heap, minimum); //Create a struct to store the data for the min child
			if(data3->priority < data2->priority){
				dynarray_set(pq->heap, count, data3); //Percolate down if necessary
				dynarray_set(pq->heap, minimum, data2); //Percolate down if necessary
				count = minimum; //Switch the value of the parent and the child if a swap takes place
			}
			else{
				return value; //Gives the value of the first element in the pq
			}
		}
	}
}
